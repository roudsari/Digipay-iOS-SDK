//
//  DPCore.h
//  DPCore
//
//  Created by Digipay on 2018-10-09.
//  Copyright © 2018 DigiPay. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DPCore.
FOUNDATION_EXPORT double DPCoreVersionNumber;

//! Project version string for DPCore.
FOUNDATION_EXPORT const unsigned char DPCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DPCore/PublicHeader.h>

#import "NSData+SHA.h"
